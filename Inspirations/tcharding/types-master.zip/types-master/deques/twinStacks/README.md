# Deque implemented using two stacks

A deque is a data structure that supports adding and removing items from both
the front and the back. These operations are typically called 'enqueue front',
'enquirer back', 'dequeue front' and 'dequeue back' (or 'enqueue left', 'enqueue
right'...). Here we use enqueueF(), enqueueB(), dequeueF(), dequeueB().
