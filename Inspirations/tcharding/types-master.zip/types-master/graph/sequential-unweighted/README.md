# Unweighted Graph

Graph nodes are labeled sequentially from 0 to N-1. Edges do not carry a
weight. Edges are stored in a slice indexed by node label.
