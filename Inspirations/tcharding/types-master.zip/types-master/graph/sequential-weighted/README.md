# Weighted Graph

Graph nodes are labeled sequentially from 0 to N-1. Edges have an integer
weight. Edges are stored in a slice indexed by node label. 
