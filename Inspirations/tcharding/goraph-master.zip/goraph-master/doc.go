// Package goraph implements graph data structure and algorithms.
package goraph // import "github.com/gyuho/goraph"
