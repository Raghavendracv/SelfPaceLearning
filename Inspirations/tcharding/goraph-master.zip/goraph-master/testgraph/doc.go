// Package testgraph contains graph test data.
package testgraph // import "github.com/gyuho/goraph/testgraph"
