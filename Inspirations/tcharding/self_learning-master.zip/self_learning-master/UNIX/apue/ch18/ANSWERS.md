Chapter 18 Terminal I/O
=======================
1. raw.c
2. You can invert parity by adding an extra bit, or changing (an unimportant ;) )
   bit.
3. MIN is 1 TIME is 0 on standard in. Cannot get values with vi running?
