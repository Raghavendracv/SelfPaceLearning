Chapter 3
=========
1. 'Unbuffered OI (read() write())' - No they are not really unbuffered because
   the kernel buffers IO'

2. ch3/dup2-fun.c - could not complete (Q -> implement dup2 without calling fcntl)

3. paper

4. paper

5. ./a.out > outfile 2>&1 <!-- redirects stdout and stderr to outfile -->
   ./a.out 2>&1 > outfile <!-- redirects stdout to outfile but stderr is not redirected -->

6. ch3/lseek-fun.c

key 
---
term - completed at terminal
paper - completed on paper
