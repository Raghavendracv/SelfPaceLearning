#ifndef NAP_H
#define NAP_H

int nap(int seconds);

#endif	/* NAP_H  */
