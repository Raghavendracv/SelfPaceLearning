Chapter 16 - Network IPC: Sockets
=================================
1. endianess.c
2. sockstat.c
3. modified tcp-ruptimed.c to fork new process for each socket address
4. remote process client/server. rpsd.c rps-cli.c `make rps`
5. tcp-ruptimed-nodelay, just removed parent call to waitpid.
6. sigio.c

