UNIX Network Programming - Chapter 29
======================================
Exercise answers - Tobin Harding.

1. The variable 'canjump' deals with the (very small) window of time after
   sigalrm signal disposition is set and before `sigsetjmp` is called.
2. Did not complete.
