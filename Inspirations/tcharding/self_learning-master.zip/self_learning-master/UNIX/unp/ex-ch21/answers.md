UNIX Network Programming - Chapter 21
======================================
Exercise answers - Tobin Harding.

1. Nothing happens, input is not echo'd.
2. No we are not allowed to `bind` a multicast address to the socket (Address
   family not supported by protocol).
3. udpcli05-ex-21.2.c
4. No hosts are multicast capable (only one host on subnet).
5. Completed on paper.
6. Did not complete.
