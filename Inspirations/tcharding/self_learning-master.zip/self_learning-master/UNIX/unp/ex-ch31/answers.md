UNIX Network Programming - Chapter 31
======================================
Exercise answers - Tobin Harding.

1. Only skimmed this chapter (STREAMS).
