/* Authors: W. R. Stevens, B. Fenner, A. M. Rudoff */ 
 
/* include readable_timeo */ 
#include "unp.h" 
 
int 
readable_timeo(int fd, int sec) 
{ 
 fd_set rset; 
 struct timeval tv; 
 
 FD_ZERO(&rset); 
 FD_SET(fd, &rset); 
 
 tv.tv_sec = sec; 
 tv.tv_usec = 0; 
 
 return(select(fd+1, &rset, NULL, NULL, &tv)); 
 /* 4> 0 if descriptor is readable */ 
} 
/* end readable_timeo */ 
 
int 
Readable_timeo(int fd, int sec) 
{ 
 int n; 
 
 if ( (n = readable_timeo(fd, sec)) < 0) 
 err_sys("readable_timeo error"); 
 return(n); 
} 
