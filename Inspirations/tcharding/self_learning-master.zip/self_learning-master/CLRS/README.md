Algorithms
==========

This tree contains algorithms implemented whilst studying the text:

**Introduction to Algorithms - Cormen, Leiserson, Rivest, Stein**  

Use at your own discretion.
