Getting Started with Linux Kernel Development
=============================================

Usual suggestions;
 - Learn C
 - Read books XYZ
 - Clone, build and run a kernel
 - Write a device driver

  
Steps
-----

- Know C well.
- Know git basics.  


  - Clone the tree (torvalds or gregKH)
    - Build kernel (make localmodconfig)
- Boot the new kernel


  - subscribe to mailing lists


  - [Know the Linux programming environment]
