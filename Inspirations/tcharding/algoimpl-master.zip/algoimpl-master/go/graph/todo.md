TODO
----
~~1) make mincut work on one large slice of shuffled edges (remove litegraph)~~
~~2) add tests for reverseEdge consistency~~
~~3) Write Dijkstras algorithm~~
4) Write tests for Dijkstras algorithm
5) change ints to int64s ?
6) do MST eager implementation: http://algs4.cs.princeton.edu/43mst/
