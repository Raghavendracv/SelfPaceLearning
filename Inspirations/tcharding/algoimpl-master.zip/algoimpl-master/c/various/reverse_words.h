#ifndef TWMB_REVERSE_WORDS
#define TWMB_REVERSE_WORDS

void reverse_words(char *words);

#endif
