#ifndef PERMUTE_LETTERS_H
#define PERMUTE_LETTERS_H

// Prints all permutations of a string.
void permute_letters(const char *letters, int len);

#endif
