#ifndef TWMB_INSERTION_SORT
#define TWMB_INSERTION_SORT

// pointer to array to sort, start index, length
void insertion_sort(int *arr, int start, int length);

#endif
