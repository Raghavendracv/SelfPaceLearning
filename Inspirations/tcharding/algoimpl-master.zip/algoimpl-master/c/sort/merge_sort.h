#ifndef TWMB_MERGE_SORT
#define TWMB_MERGE_SORT

void merge_sort(int *scrambled, int from, int to);

#endif
